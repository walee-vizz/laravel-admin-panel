<?php $__env->startSection('title', 'Blank layout - Layouts'); ?>

<?php $__env->startSection('content'); ?>
<h4 class="p-4">Blank Page</h4>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\html-laravel-version - Copy\Bootstrap5\full-version\resources\views/content/layouts-example/layouts-blank.blade.php ENDPATH**/ ?>