<?php
$customizerHidden = 'customizer-hide';
$configData = Helper::appClasses();
?>



<?php $__env->startSection('title', 'Coming Soon - Pages'); ?>

<?php $__env->startSection('page-style'); ?>
<!-- Page -->
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/css/pages/page-misc.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Coming soon -->
<div class="container-xxl container-p-y">
  <div class="misc-wrapper">
    <h2 class="mb-1 mx-2">We are launching soon</h2>
    <p class="mb-4 mx-2">We're creating something awesome. Please subscribe to get notified when it's ready!</p>
    <form onsubmit="return false" class="mb-4">
      <div class="mb-0">
        <div class="input-group">
          <input type="text" class="form-control" placeholder="email" autofocus>
          <button type="submit" class="btn btn-primary">Notify</button>
        </div>
      </div>
    </form>
    <div class="mt-4">
      <img src="<?php echo e(asset('assets/img/illustrations/page-misc-launching-soon.png')); ?>" alt="page-misc-launching-soon" width="263" class="img-fluid">
    </div>
  </div>
</div>
<div class="container-fluid misc-bg-wrapper">
  <img src="<?php echo e(asset('assets/img/illustrations/bg-shape-image-'.$configData['style'].'.png')); ?>" alt="page-misc-coming-soon" data-app-light-img="illustrations/bg-shape-image-light.png" data-app-dark-img="illustrations/bg-shape-image-dark.png">
</div>
<!-- /Coming soon -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vuexy\html-laravel\full-version\resources\views/content/pages/pages-misc-comingsoon.blade.php ENDPATH**/ ?>