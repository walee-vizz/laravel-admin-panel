<?php
$configData = Helper::appClasses();
?>



<?php $__env->startSection('title', 'Collapsed menu - Layouts'); ?>

<?php $__env->startSection('content'); ?>


<!-- Layout Demo -->
<div class="layout-demo-wrapper">
  <div class="layout-demo-placeholder">
    <img src="<?php echo e(asset('assets/img/layouts/layout-collapsed-menu-'.$configData['style'].'.png')); ?>" class="img-fluid" alt="Layout collapsed menu" data-app-light-img="layouts/layout-collapsed-menu-light.png" data-app-dark-img="layouts/layout-collapsed-menu-dark.png">
  </div>
  <div class="layout-demo-info">
    <h4>Layout collapsed menu</h4>
    <div class="alert alert-primary mt-4" role="alert">
      <span class="fw-medium">Important:</span> If you have enabled localStorage then the menu (navigation) will be synced with localStorage value.
    </div>
  </div>
</div>
<!--/ Layout Demo -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vuexy\html-laravel\full-version\resources\views/content/layouts-example/layouts-collapsed-menu.blade.php ENDPATH**/ ?>