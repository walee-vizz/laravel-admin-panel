<?php
$breadcrumbs = [['link' => 'home', 'name' => 'Home'], ['name' => 'Team Settings']];
?>

<?php $__env->startSection('title', 'Team Settings'); ?>

<?php $__env->startSection('content'); ?>
  <div class="mb-4">
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('teams.update-team-name-form', ['team' => $team]);

$__html = app('livewire')->mount($__name, $__params, 'BQWasC1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
  </div>

  <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('teams.team-member-manager', ['team' => $team]);

$__html = app('livewire')->mount($__name, $__params, 'WDjBanx', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>


  <?php if(Gate::check('delete', $team) && !$team->personal_team): ?>

  <div class="mt-4">
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('teams.delete-team-form', ['team' => $team]);

$__html = app('livewire')->mount($__name, $__params, '03yDatg', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
  </div>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vuexy\html-laravel\full-version\resources\views/teams/show.blade.php ENDPATH**/ ?>