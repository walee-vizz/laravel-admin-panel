<?php
$configData = Helper::appClasses();
$isFlex = true;
?>



<?php $__env->startSection('title', 'Content navbar + Sidebar - Layouts'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex-shrink-1 flex-grow-0 w-px-350 border-end container-p-x container-p-y">
  <div class="layout-example-sidebar layout-example-content-inner">
    Sidebar
  </div>
</div>

<div class="flex-shrink-1 flex-grow-1 container-p-x container-p-y">
  <!-- Layout Demo -->
  <div class="layout-demo-wrapper">
    <div class="layout-demo-placeholder">
      <img src="<?php echo e(asset('assets/img/layouts/layout-content-navbar-and-sidebar-'.$configData['style'].'.png')); ?>" class="img-fluid" alt="Layout content navbar + sidebar" data-app-light-img="layouts/layout-content-navbar-and-sidebar-light.png" data-app-dark-img="layouts/layout-content-navbar-and-sidebar-dark.png">
    </div>
    <div class="layout-demo-info">
      <h4>Layout content navbar + sidebar</h4>
      <p>Container layout sets a <code>max-width</code> at each responsive breakpoint.</p>
    </div>
  </div>
  <!--/ Layout Demo -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\html-laravel-version\Bootstrap5\full-version\resources\views/content/layouts-example/layouts-content-navbar-with-sidebar.blade.php ENDPATH**/ ?>